#!/usr/bin/env python3
import argparse
import hashlib
import secrets
from pathlib import Path

from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad

SALT = b"ENCRYPCCINO"
WARNING = "If you lose your passphrase, we cannot restore access to your data.\nMake sure you save your passphrase in a safe place."

with open(Path(__file__).parent / "words.txt") as f:
    words = [w.strip() for w in f.readlines()]


def main():
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group()
    group.add_argument(
        "-e", "--encrypt", action="store_true", help="encrypt with random passphrase"
    )
    group.add_argument(
        "-d", "--decrypt", metavar="passphrase", help="decrypt with passphrase"
    )
    parser.add_argument("files", nargs="+")
    args = parser.parse_args()
    if args.encrypt:
        encrypt_all(args.files)
    elif args.decrypt:
        passphrase = args.decrypt.strip().split(" ")
        decrypt_all(args.files, passphrase)
    else:
        parser.print_help()


def encrypt_all(files):
    passphrase = generate_passphrase(2)
    passphrase_str = " ".join(passphrase)
    print(f"Your passphrase:\n{passphrase_str}\n\n{WARNING}")
    for file in files:
        with open(file, "rb") as f:
            data = f.read()
        for word in passphrase:
            data = encrypt(word, data)
        with open(f"{file}.enc", "wb") as f:
            f.write(data)


def decrypt_all(files, passphrase):
    for file in files:
        with open(f"{file}.enc", "rb") as f:
            data = f.read()
        for word in reversed(passphrase):
            data = decrypt(word, data)
        with open(file, "wb") as f:
            f.write(data)


# https://xkcd.com/936/
def generate_passphrase(strength):
    return [secrets.choice(words) for _ in range(strength)]


def encrypt(password, plaintext):
    return cipher(password).encrypt(pad(plaintext, 16))


def decrypt(password, ciphertext):
    return unpad(cipher(password).decrypt(ciphertext), 16)


def cipher(password):
    digest = hashlib.sha256(password.encode() + SALT).digest()
    key, iv = digest[:16], digest[16:]
    return AES.new(key, AES.MODE_CBC, iv)


if __name__ == "__main__":
    main()
